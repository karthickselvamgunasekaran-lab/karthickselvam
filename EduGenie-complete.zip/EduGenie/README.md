# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight educational assistant built with FastAPI and a simple HTML/CSS/JavaScript frontend.

## Features

- Question answering
- Beginner-friendly concept explanations
- 3-question MCQ quiz generation
- Educational text summarization
- Beginner-to-advanced learning paths
- JSON validation for quiz responses
- Health endpoint
- Responsive browser interface
- Optional local LaMini-Flan-T5 explanation model

The project follows the original documentation's module structure while using Google's current `google-genai` Python SDK.

## Project structure

```text
EduGenie/
├── main.py
├── config.py
├── gemini_client.py
├── qna.py
├── explanation_module.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── tests/
    ├── test_api.py
    └── test_quiz.py
```

## VS Code setup

### 1. Install Python

Use Python 3.10 or newer.

Check:

```bash
python --version
```

### 2. Open the project

Open the `EduGenie` folder in VS Code.

### 3. Create a virtual environment

Windows:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Configure Gemini

Copy `.env.example` to `.env` and put your Gemini API key in:

```env
GEMINI_API_KEY=your_key_here
```

Do not commit `.env` to Git.

### 6. Run

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

The original project documentation also specifies running with `uvicorn main:app --reload`. 

## API endpoints

- `GET /health`
- `POST /qa`
- `POST /explain`
- `POST /quiz`
- `POST /summarize`
- `POST /learn/recommendations`

POST body:

```json
{
  "text": "Explain photosynthesis."
}
```

## Testing

Run:

```bash
pytest -q
```

The tests verify the API routes and quiz validation logic without making real Gemini calls.

## Optional local LaMini explanation

The documentation describes LaMini-Flan-T5-783M as the local explanation model. This implementation keeps that option, but disables it by default so a normal installation does not need the large PyTorch/Transformers stack.

To enable it:

```bash
pip install torch transformers sentencepiece
```

Then set:

```env
LOCAL_EXPLANATION_ENABLED=true
```

The first local explanation may download the model from Hugging Face and therefore needs internet access and additional disk/RAM. If the local model fails, EduGenie falls back to Gemini.

## Troubleshooting

### "GEMINI_API_KEY is missing"

Create `.env` from `.env.example` and set a valid key.

### Model unavailable

Set `GEMINI_MODEL` to a Gemini model available to your API account. The model name is intentionally configurable.

### Port already in use

```bash
uvicorn main:app --reload --port 8001
```

Then open `http://127.0.0.1:8001`.

### API works but the page does not

Check that `templates/index.html` and `static/` exist in the project root and that Uvicorn was started from the `EduGenie` directory.

## Security notes

- Never expose your Gemini API key in frontend JavaScript.
- Keep `.env` out of source control.
- Add authentication/rate limiting before deploying publicly.
- Treat AI output as educational assistance and verify important academic facts.
