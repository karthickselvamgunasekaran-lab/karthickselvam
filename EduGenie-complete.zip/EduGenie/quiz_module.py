import json
import re
from typing import List

from pydantic import BaseModel, Field, ValidationError
from gemini_client import generate_text


class QuizQuestion(BaseModel):
    question: str
    options: List[str] = Field(min_length=4, max_length=4)
    correct_answer: str


class QuizResponse(BaseModel):
    questions: List[QuizQuestion] = Field(min_length=3, max_length=3)


def clean_json_block(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def generate_quiz(passage: str) -> dict:
    prompt = f"""Create exactly 3 multiple-choice questions from this educational text.

TEXT:
{passage}

Return ONLY valid JSON with this exact shape:
{{
  "questions": [
    {{
      "question": "Question text",
      "options": ["A", "B", "C", "D"],
      "correct_answer": "A"
    }}
  ]
}}

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- correct_answer must exactly match one option.
- Questions must be answerable from the supplied text.
- Do not use Markdown or extra commentary."""
    try:
        raw = generate_text(
            prompt,
            system_instruction="You generate reliable educational MCQs as strict JSON.",
        )
        data = json.loads(clean_json_block(raw))
        validated = QuizResponse.model_validate(data)
        return validated.model_dump()
    except (json.JSONDecodeError, ValidationError) as exc:
        return {
            "error": "Gemini returned quiz data that could not be validated.",
            "details": str(exc),
        }
    except Exception as exc:
        return {"error": f"Unable to generate quiz right now: {exc}"}
