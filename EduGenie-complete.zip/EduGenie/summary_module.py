from gemini_client import generate_text


def summarize_text(text: str) -> str:
    prompt = f"""Summarize the following educational passage for quick revision.

PASSAGE:
{text}

Requirements:
- Keep the important facts and ideas.
- Remove repetition and filler.
- Use simple language.
- Prefer a short paragraph followed by 3-5 bullet points.
- Do not invent facts."""
    try:
        return generate_text(
            prompt,
            system_instruction="You are an educational summarization assistant.",
        )
    except Exception as exc:
        return f"Unable to summarize right now: {exc}"
