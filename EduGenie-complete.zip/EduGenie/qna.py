from gemini_client import generate_text

SYSTEM = (
    "You are EduGenie, a friendly educational assistant. "
    "Answer academic questions accurately and concisely. "
    "Use simple language suitable for a learner. "
    "If the question is ambiguous, state the assumption you made."
)


def answer_question(question: str) -> str:
    prompt = f"""Answer this student's question.

Question:
{question}

Give the answer first, then a short explanation or example when useful."""
    try:
        return generate_text(prompt, system_instruction=SYSTEM)
    except Exception as exc:
        return f"Unable to answer right now: {exc}"
