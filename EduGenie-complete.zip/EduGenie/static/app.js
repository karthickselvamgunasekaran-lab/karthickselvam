const task = document.getElementById("task");
const inputText = document.getElementById("inputText");
const submitBtn = document.getElementById("submitBtn");
const result = document.getElementById("result");
const status = document.getElementById("status");
const copyBtn = document.getElementById("copyBtn");

const endpointMap = {
  qa: "/qa",
  explain: "/explain",
  quiz: "/quiz",
  summarize: "/summarize",
  learn: "/learn/recommendations"
};

const placeholders = {
  qa: "Example: Which is the largest ocean?",
  explain: "Example: Explain photosynthesis in simple words.",
  quiz: "Paste a passage or topic to turn into 3 MCQs.",
  summarize: "Paste the educational passage you want summarized.",
  learn: "Example: I want to learn SQL from beginner to advanced."
};

task.addEventListener("change", () => {
  inputText.placeholder = placeholders[task.value];
});

function formatResponse(data) {
  if (data.result) return data.result;
  if (data.questions) {
    return data.questions.map((q, i) => {
      const options = q.options.map((o, j) => `${String.fromCharCode(65 + j)}. ${o}`).join("\n");
      return `${i + 1}. ${q.question}\n${options}\nAnswer: ${q.correct_answer}`;
    }).join("\n\n");
  }
  if (data.error) return `${data.error}\n\n${data.details || ""}`;
  return JSON.stringify(data, null, 2);
}

submitBtn.addEventListener("click", async () => {
  const text = inputText.value.trim();
  if (!text) {
    result.textContent = "Please enter a question, topic, or passage.";
    return;
  }

  submitBtn.disabled = true;
  status.textContent = "Generating…";
  result.textContent = "EduGenie is thinking…";

  try {
    const response = await fetch(endpointMap[task.value], {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({text})
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "The server returned an error.");
    }

    result.textContent = formatResponse(data);
    status.textContent = "Ready";
  } catch (error) {
    result.textContent = `Error: ${error.message}`;
    status.textContent = "Error";
  } finally {
    submitBtn.disabled = false;
  }
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(result.textContent);
  copyBtn.textContent = "Copied";
  setTimeout(() => copyBtn.textContent = "Copy", 1200);
});
