from gemini_client import generate_text


def get_learning_recommendations(topic: str) -> str:
    prompt = f"""Create a personalized learning path for the topic below.

Topic: {topic}

Structure the plan from beginner to advanced:
1. Prerequisites
2. Beginner topics
3. Intermediate topics
4. Advanced topics
5. Suggested timeline
6. Practice/project ideas
7. Useful resource types (videos, articles, books, documentation)

Keep it practical and clear. Do not invent specific URLs."""
    try:
        return generate_text(
            prompt,
            system_instruction=(
                "You are a learning-path designer. Adapt the sequence "
                "to a beginner unless the user clearly indicates another level."
            ),
        )
    except Exception as exc:
        return f"Unable to create a learning path right now: {exc}"
