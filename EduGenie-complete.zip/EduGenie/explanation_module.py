from functools import lru_cache

from config import settings
from gemini_client import generate_text


def _local_explain(topic: str) -> str:
    try:
        from transformers import pipeline
    except ImportError as exc:
        raise RuntimeError(
            "Local explanation requires transformers. Install requirements.txt."
        ) from exc

    generator = _get_local_pipeline()
    prompt = (
        "Explain the following topic to a beginner in simple language. "
        "Use a short definition, key points, and one example.\n\n"
        f"Topic: {topic}"
    )
    result = generator(prompt, max_new_tokens=180, do_sample=False)
    return result[0]["generated_text"].strip()


@lru_cache(maxsize=1)
def _get_local_pipeline():
    from transformers import pipeline

    return pipeline(
        "text2text-generation",
        model=settings.local_explanation_model,
    )


def explain_concept(topic: str) -> str:
    if settings.local_explanation_enabled:
        try:
            return _local_explain(topic)
        except Exception:
            # Fall back to Gemini so the feature remains usable if the
            # optional local model is unavailable.
            pass

    prompt = f"""Explain the topic below to a beginner.

Topic: {topic}

Format:
1. Simple definition
2. 3-5 key points
3. One easy example
4. One-line recap

Avoid unnecessary jargon."""
    try:
        return generate_text(
            prompt,
            system_instruction=(
                "You are a patient teacher. Make difficult concepts "
                "easy without losing important meaning."
            ),
        )
    except Exception as exc:
        return f"Unable to generate an explanation right now: {exc}"
