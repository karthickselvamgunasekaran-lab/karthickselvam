import json
from quiz_module import clean_json_block, QuizResponse


def test_clean_json_block():
    raw = """```json
{"questions":[]}
```"""
    assert clean_json_block(raw) == '{"questions":[]}'


def test_quiz_schema():
    data = {
        "questions": [
            {
                "question": "2 + 2 = ?",
                "options": ["1", "2", "3", "4"],
                "correct_answer": "4",
            },
            {
                "question": "Capital of France?",
                "options": ["Paris", "Rome", "Berlin", "Madrid"],
                "correct_answer": "Paris",
            },
            {
                "question": "Water formula?",
                "options": ["CO2", "H2O", "O2", "NaCl"],
                "correct_answer": "H2O",
            },
        ]
    }
    validated = QuizResponse.model_validate(data)
    assert len(validated.questions) == 3
